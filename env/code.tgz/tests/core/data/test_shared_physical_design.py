"""`shared_physical_design`: every data model gets the same indexes, id index kind and
storage choice, and the seed is otherwise the one it was."""
import dataclasses

from ganda.core.data.generator import build
from ganda.orientdb.provider.config import OrientConfig
from ganda.orientdb.provider.provider import PROVIDER as ORIENTDB
from ganda.surrealdb.provider.config import SurrealConfig
from ganda.surrealdb.provider.provider import PROVIDER as SURREALDB

AXES = dict(inheritance_probability=0.5, list_index_probability=0.5, custom_key_probability=0.5, narrow_type_probability=0.5, date_map_probability=0.5)


def _without_data_model(schema):
    return [dataclasses.replace(ix, data_model="both") for ix in schema.indexes]


def test_every_index_is_on_every_data_model_and_the_seed_is_unchanged():
    single = 0
    for seed in range(40000, 40030):
        cfg = OrientConfig(**AXES)
        apart, inst_apart, _ = build(seed, cfg, ORIENTDB)
        shared, inst_shared, _ = build(seed, dataclasses.replace(cfg, shared_physical_design=True), ORIENTDB)
        single += sum(ix.data_model != "both" for ix in apart.indexes)
        assert all(ix.data_model == "both" for ix in shared.indexes)
        assert len(set(shared.id_index.values())) <= 1 and (not shared.id_index or set(shared.id_index) == set(ORIENTDB.data_models))
        assert shared.node_types == apart.node_types and shared.edge_types == apart.edge_types and shared.base == apart.base
        # the same indexes (less the ones that now collide on some data model)
        assert set(shared.indexes) <= set(_without_data_model(apart))
        assert inst_shared.nodes == inst_apart.nodes and inst_shared.edges == inst_apart.edges and inst_shared.churn == inst_apart.churn
    assert single > 0  # the seeds do draw single-data-model indexes


def test_surrealdb_declares_a_class_schemafull_on_every_data_model_or_none():
    cfg = SurrealConfig(schemafull_probability=0.5, shared_physical_design=True)
    seen = set()
    for seed in range(40000, 40020):
        schema, _, _ = build(seed, cfg, SURREALDB)
        for nt in schema.node_types:
            full = dict(nt.options).get("schemafull", ())
            assert full in ((), SURREALDB.data_models)
            seen.add(full)
    assert seen == {(), SURREALDB.data_models}
